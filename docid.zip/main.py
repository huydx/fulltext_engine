#-*- coding: utf-8 -*-
import sys
import codecs
from tokenizer import Tokenizer

test_tokenizer = Tokenizer()
test_tokenizer.test()

